const dynamo = require('../database/dynamo');
const bcrypt = require('bcryptjs');

exports.all = async (req, res) => {
    const params = {
        TableName: 'user',
    };
    const users = await dynamo.dynamoClient.scan(params).promise();
    console.log(users);
    res.json(users);
}

exports.one = async (req, res) => {
    const params = {
        TableName: 'user',
        Item: {
            userid: req.params.id
        }
    };
    const user = await dynamo.dynamoClient.scan(params).promise();
    res.json(user);
}

exports.oneusername = async (req, res) => {
    const params = {
        TableName: 'user',
        Item: {
            username: req.params.username
        }
    };
    const user = await dynamo.dynamoClient.scan(params).promise();
    res.json(user);
}

exports.create = async(req, res) => {
    let pass = null;

    bcrypt.genSalt(10, function(err, salt) {
        bcrypt.hash(req.body.password, salt, function(err, hash) {
            pass = hash;
        });
    });

    const params = {
        TableName: 'user',
        Item: {
            userid: req.body.userid,
            fullname: req.body.fullname,
            username: req.body.username,
            email: req.body.email,
            password_hash: pass,
            datejoined: req.body.datejoined
        }
    };
    const user = await dynamo.dynamoClient.put(params).promise();
    res.json(user);
};

exports.update = async(req, res) => {
    const params = {
        TableName: 'user',
        Item: req.body
    };
    const user = await dynamo.dynamoClient.put(params).promise();
    res.json(user);
};